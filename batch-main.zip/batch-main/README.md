# batch


Question 2   (Si vous souhaitez monter en grade, répondez au mieux à cette question)

Automatisez à l’aide d’un script batch les instructions suivantes sur le bureau :

Affichez « Veuillez entrer votre indice IMC ! » sur le prompt

Saisissez l’IMC que l’utilisateur entre en ligne de commande

Si l’IMC de l’utilisateur est inférieur à 18, affichez « Vous avez une insuffisance pondérale ».

Si l’IMC est entre 18 compris et 25 non compris, affichez « Vous avez une corpulence normale ».

Si l’IMC est entre 25 compris et 30 non compris, affichez « Vous êtes en surpoids »

Si l’IMC est entre 30 compris et 35 non compris, affichez « Vous êtes en obésité modérée ».

Si l’IMC est ente 35 compris et 40 non compris, affichez « Vous êtes en obésité sévère ».

Si l’IMC est supérieur ou égal à 40, affichez « Vous êtes en obésité morbide ».

Faites-en sorte de ne pas devoir relancer le script à chaque fois qu’un utilisateur entre son IMC.

Effacez l’écran entre chaque utilisateur.
